const axios = require('axios');
const cluster = require('cluster');
const path = require('path');
const nodemailer = require('nodemailer');
const fs = require('fs');
const moment = require("moment-timezone");
const Readline = require('readline');
const yargs = require('yargs/yargs');
const chalk = require('chalk');
const os = require('os');

const rl = Readline.createInterface(process.stdin, process.stdout);

let otpCode = null;
let allowedIPs = [];
let validNames = [];
let oneKey = null;
let attempts = 0;
const verify = JSON.parse(fs.readFileSync('./system/verify.json', 'utf-8'));

const storedHexPassword = '6a657373696361206368616e647261';
const storedPassword = hexToText(storedHexPassword);

function hexToText(hex) {
  let result = '';
  for (let i = 0; i < hex.length; i += 2) {
    result += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
  }
  return result;
}

async function fetchAllowedIPs() {
  try {
    const response = await axios.get('https://www.valzyofc.my.id/posts/iplist');
    const pageContent = response.data;

    const ipRegex = /IP:([\d\.]+)/g;
    let match;
    allowedIPs = [];

    while ((match = ipRegex.exec(pageContent)) !== null) {
      allowedIPs.push(match[1].trim());
    }

    console.log(chalk.green(''));
  } catch (error) {
    console.log(chalk.red('Gagal memuat daftar IP yang diizinkan:', error));
    allowedIPs = [];
  }
}

async function fetchValidNames() {
  try {
    const response = await axios.get('https://www.valzyofc.my.id/posts/nomor');
    const pageContent = response.data;

    const nameRegex = /NAMA:\s*([A-Za-z\s]+)/g;
    let match;
    validNames = [];

    while ((match = nameRegex.exec(pageContent)) !== null) {
      const extractedName = match[1].trim();
      validNames.push(extractedName);
    }

    console.log(chalk.green(''));
  } catch (error) {
    console.log(chalk.red('Gagal memuat daftar nama yang valid:', error));
    validNames = [];
  }
}

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function sendOtp(email) {
  otpCode = `${getRandomInt(100, 900)}-${getRandomInt(100, 900)}`;
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    auth: {
      user: 'kemiisalsabila@gmail.com',
      pass: 'dxghrdutrlazxvlm'
    }
  });

  const mailOptions = {
    from: {
      name: 'Kemii Cantik',
      address: 'kemiisalsabila@gmail.com'
    },
    to: 'itsvalzy@stayhome.li',
    subject: 'Email Verification',
    html: `<body style="margin: 0; padding: 0; font-family: 'Baloo 2', sans-serif; background: #f2f2fd; color: #222;">
        <div style="font-family: 'Baloo 2', sans-serif; padding: 20px; color: #333; background-color: #ffffff; max-width: 640px; margin: 100px auto; border-radius: 10px; box-shadow: 0px 20px 48px rgba(0, 0, 0, 0.2); text-align: center;">
            <div style="margin-bottom: 20px;">
                <h1 style="font-size: 33px; margin: 0; color: #222;">Welcome!</h1>
                <img src="https://telegra.ph/file/e10ff846266d15dbee0c0.jpg" alt="Image" style="width: 100%; max-width: 400px; border-radius: 10px;">
            </div>
            <h2 style="font-size: 26px; margin-bottom: 20px;">Confirm Email Address</h2>
            <p style="font-size: 18px; margin-bottom: 20px;">
                Please verify the code to access the bot. You need to enter the verification code sent to your email to continue using the bot services.
            </p>
            <h2 style="font-size: 26px; margin-bottom: 20px;">Secret Code</h2>
            <p style="font-size: 18px; margin-bottom: 20px;">
                This code is confidential. Do not share this code with anyone. You can send the code to the bot via private chat.
            </p>
            <div style="text-align: center; background-color: #ffffff; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #ddd;">
                <h1 style="margin: 0; color: #333; font-size: 32px; font-weight: bold;">${otpCode}</h1>
            </div>
        </div>
    </body>`
  };

  transporter.sendMail(mailOptions, function (err, data) {
    if (err) {
      console.log(chalk.red('SMTP Error!'));
      return chooseAuthMethod();
    }
    console.log(chalk.green('Check your mailbox to get a verification code.'));
    verifyOtp();
  });
}

function verifyOtp() {
    console.log('\n' + chalk.bgYellow.black(' 🔐 Masukkan Otp: 🔐 '));
  rl.question(chalk.yellow('Otp: '), (inputOtp) => {
    if (inputOtp === otpCode) {
      console.log(chalk.green('OTP benar! Akses diterima.'));
      start('main.js');
    } else {
      console.log(chalk.red('OTP salah! Silakan coba lagi.'));
      verifyOtp();
    }
  });
}

function promptPassword() {
  console.log('\n' + chalk.bgCyan.black(' 🔐 Masukkan Password: 🔐 '));
  rl.question(chalk.yellow('Password: '), (inputPassword) => {
    if (inputPassword === storedPassword) {
      console.log(`
 ╭┈❲ ${chalk.redBright('NEXTZY Team - Valzyy')}
 ╞❴ Status ❵ ${chalk.greenBright('✅ Akses Diterima! ✅')}
 ╰╼┈⟐ ❰ Powered by : valzyy ❱
`);
      start('main.js');
    } else {
      console.log(`
 ╭┈❲ ${chalk.redBright('NEXTZY Team - Valzyy')}
 ╞❴ Status ❵ ${chalk.redBright('❌ Password salah! ❌')}
 ╰╼┈⟐ ❰ Powered by : valzyy ❱
`);
      attempts++;
      if (attempts < 3) {
        console.log(chalk.bgYellow.black(`\n⏳ Kesempatan tersisa: ${3 - attempts}`));
        promptPassword();
      } else {
        console.log(chalk.bgRed.white('\n⚠️ Kesempatan habis! Menghapus semua file di folder... ⚠️'));
        deleteAllFiles();
        rl.close();
      }
    }
  });
}

async function isNameValid(name) {
  await fetchValidNames();
  const cleanName = name.replace(/[^A-Za-z\s]/g, '').trim();
  return validNames.includes(cleanName);
}

function generateOneKey() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%^&*';
  let result = '';
  const length = 12;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

function handleOneKeyAuthentication() {
  console.log('\n' + chalk.bgCyan.black(' 🏷️ Masukkan Nama: 🏷️ '));
  rl.question(chalk.yellow('Masukkan nama Anda untuk verifikasi: '), async (inputName) => {
    if (await isNameValid(inputName)) {
      oneKey = generateOneKey();
      console.log(chalk.green(`Your One Key is: ${oneKey}`));
      rl.question(chalk.yellow('Masukkan One Key untuk autentikasi: '), (inputKey) => {
        if (inputKey === oneKey) {
          console.log(chalk.green('One Key benar! Akses diterima.'));
          start('main.js');
        } else {
          console.log(chalk.red('One Key salah! Silakan coba lagi.'));
          handleOneKeyAuthentication();
        }
      });
    } else {
      console.log(chalk.red('Nama tidak valid atau tidak terdaftar!'));
      handleOneKeyAuthentication();
    }
  });
}

function handleIPAuthentication() {
  const userIP = getLocalIPAddress();
  console.log(`
 ╭┈❲ ${chalk.redBright('NEXTZY Team - Valzyy')}
 ╞❴ IP Anda ❵ ${chalk.blueBright(userIP)}
 ╰╼┈⟐ ❰ Powered by : valzyy ❱
`);

  if (isIPAllowed(userIP)) {
    console.log(chalk.green('IP diizinkan! Akses diterima.'));
    start('main.js');
  } else {
    console.log(chalk.red('IP tidak diizinkan! Akses ditolak.'));
    rl.close();
  }
}

function isIPAllowed(ip) {
  return allowedIPs.includes(ip);
}

function displayWelcomeMessage() {
  const localIp = getLocalIPAddress();
  const developerName = 'Valzyy';
  const developerRole = 'Fullstack';
  const twitterHandle = '@valzyycans';
  const linkedinProfile = 'https://www.valzyofc.my.id';
  const githubProfile = '6285701479245';

  console.log(`
╭┈❲ ${chalk.redBright('NEXTZY Team - Valzyy')}
╞❴ Status ❵ ${chalk.greenBright('🛠️ Selamat datang!')}
╰╼┈⟐ ❰ Powered by : valzyy ❱

╭┈❲ ${chalk.blueBright('Developer Information')}
╞❴ Nama ❵ ${chalk.greenBright(developerName)}
╞❴ Peran ❵ ${chalk.greenBright(developerRole)}
╰╼┈⟐ ❰ Powered by : valzyy ❱

╭┈❲ ${chalk.blueBright('Social Media')}
╞❴ Twitter ❵ ${chalk.cyan(twitterHandle)}
╞❴ Website ❵ ${chalk.cyan(linkedinProfile)}
╞❴ WhatsApp ❵ ${chalk.cyan(githubProfile)}
╰╼┈⟐ ❰ Powered by : valzyy ❱

╭┈❲ ${chalk.blueBright('Local IP Address')}
╞❴ IP ❵ ${chalk.yellow(localIp)}
╰╼┈⟐ ❰ Powered by : valzyy ❱
\n`);
console.log(`\n`);
}

function getLocalIPAddress() {
  const interfaces = os.networkInterfaces();
  let localIp = 'IP tidak ditemukan';

  for (const iface in interfaces) {
    for (const details of interfaces[iface]) {
      if (details.family === 'IPv4' && !details.internal) {
        localIp = details.address;
        break;
      }
    }
  }

  return localIp;
}

function deleteAllFiles() {
  const directory = './system';
  fs.readdir(directory, (err, files) => {
    if (err) {
      console.error(`Gagal membaca direktori ${directory}: ${err}`);
      return;
    }

    files.forEach((file) => {
      fs.unlink(path.join(directory, file), (err) => {
        if (err) {
          console.error(`Gagal menghapus file ${file}: ${err}`);
        } else {
          console.log(`File ${file} dihapus.`);
        }
      });
    });
  });
}

function start(script) {
  require('child_process').fork(script);
}

function chooseAuthMethod() {
  console.log(`
 ╭┈❲ ${chalk.redBright('NEXTZY Team - Valzyy')}
 ╞❴ Status ❵ ${chalk.greenBright('🛠️ Pilih metode otentikasi: 🛠️')}
╰╼┈⟐ ❰ Powered by : valzyy ❱
╭┈❲ ${chalk.greenBright('1. IP Authentication (Error).')}
╞❴ Status ❵ ${chalk.yellow('Menyesuaikan IP Anda')}
╰╼┈⟐ ❰ Powered by : valzyy ❱
╭┈❲ ${chalk.greenBright('2. Password Authentication')}
╞❴ Status ❵ ${chalk.yellow('Menyesuaikan Password Anda')}
╰╼┈⟐ ❰ Powered by : valzyy ❱
╭┈❲ ${chalk.greenBright('3. OTP Authentication')}
╞❴ Status ❵ ${chalk.yellow('Mengirim OTP ke email Anda')}
╰╼┈⟐ ❰ Powered by : valzyy ❱
╭┈❲ ${chalk.greenBright('4. One Key Authentication')}
╞❴ Status ❵ ${chalk.yellow('Menggunakan One Key untuk autentikasi')}
╰╼┈⟐ ❰ Powered by : valzyy ❱
`);

  rl.question(chalk.yellow('Pilih metode otentikasi (1/2/3/4): '), (choice) => {
    switch (choice) {
      case '1':
        handleIPAuthentication();
        break;
      case '2':
        promptPassword();
        break;
      case '3':
          console.log('\n' + chalk.bgRed.white(' ‼️ Otp Akan Terkirim Pada Valzy (y/n) ‼️'));
        rl.question(chalk.yellow('Jawaban: '), (email) => {
          sendOtp(email);
        });
        break;
      case '4':
        handleOneKeyAuthentication();
        break;
      default:
        console.log(chalk.red('Pilihan tidak valid!'));
        chooseAuthMethod();
        break;
    }
  });
}

displayWelcomeMessage();
console.log('\n');
fetchAllowedIPs();
fetchValidNames();
chooseAuthMethod();

var isRunning = false;

function start(file) {
  if (isRunning) return;
  isRunning = true;
  let args = [path.join(__dirname, file), ...process.argv.slice(2)];
  console.log(chalk.yellow('\nMemuat Skrip...'));
  cluster.setupMaster({
    exec: args[0],
    args: args.slice(1),
  });
  let p = cluster.fork();
  p.on('message', data => {
    console.log(chalk.cyan('[RECEIVED]'), data);
    switch (data) {
      case 'reset':
        p.process.kill();
        isRunning = false;
        start.apply(this, arguments);
        break;
      case 'uptime':
        p.send(process.uptime());
        break;
    }
  });
  p.on('exit', (_, code) => {
    isRunning = false;
    console.error(chalk.red('[❌] Exited with code:'), code);
    if (code === 0) return;
    fs.watchFile(args[0], () => {
      fs.unwatchFile(args[0]);
      start(file);
    });
  });
  let opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse());
  if (!opts['test'])
    if (!rl.listenerCount()) rl.on('line', line => {
      p.emit('message', line.trim());
    });
}
