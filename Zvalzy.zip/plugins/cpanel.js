const fetch = require('node-fetch');
const crypto = require('crypto');
const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

module.exports = async (conn, m, msg, global, command, isOwner, isReseller, isGroup, qchanel) => {
  if (!isOwner && !isReseller) return conn.sendMessage(m.chat, msg.owner, { quoted: m });

  if (global.panel == null) return conn.sendMessage(m.chat, 'Nama/Username Tidak Ditemukan', { quoted: m });

  const setApiDetails = (apikey, domain, egg) => {
    global.apikey = apikey;
    global.domain = domain;
    global.egg = egg;
  };

  let apikey = global.apikey || ''; // Default value if not set
  let domain = global.domain || ''; // Default value if not set
  let egg = global.egg || ''; // Default value if not set

  let ram, disknya, cpu;

  switch (command) {
    case "cp1gb": ram = "1125"; disknya = "1125"; cpu = "40"; break;
    case "cp2gb": ram = "2125"; disknya = "2125"; cpu = "60"; break;
    case "cp3gb": ram = "3125"; disknya = "3125"; cpu = "80"; break;
    // Add cases up to cp50gb
    case "cp50gb": ram = "50125"; disknya = "50125"; cpu = "1500"; break;
    case "cpunli": ram = "0"; disknya = "0"; cpu = "0"; break;
    default: ram = "0"; disknya = "0"; cpu = "0"; break;
  }

  if (!isOwner && !isReseller) return conn.sendMessage(m.chat, msg.owner, { quoted: m });

  let username = global.panel[0].toLowerCase();
  let email = `${username}@gmail.com`;
  let name = username.charAt(0).toUpperCase() + username.slice(1);
  let password = username + crypto.randomBytes(2).toString('hex');

  let f = await fetch(`${domain}/api/application/users`, {
    "method": "POST",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apikey}`
    },
    "body": JSON.stringify({
      "email": email,
      "username": username.toLowerCase(),
      "first_name": name,
      "last_name": "Server",
      "language": "en",
      "password": password.toString()
    })
  });
  
  let data = await f.json();
  if (data.errors) return conn.sendMessage(m.chat, JSON.stringify(data.errors[0], null, 2), { quoted: m });

  let user = data.attributes;
  let desc = new Date().toLocaleString();
  let usr_id = user.id;
  let f1 = await fetch(`${domain}/api/application/nests/5/eggs/${egg}`, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apikey}`
    }
  });

  let data2 = await f1.json();
  let startup_cmd = data2.attributes.startup;
  let f2 = await fetch(`${domain}/api/application/servers`, {
    "method": "POST",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apikey}`,
    },
    "body": JSON.stringify({
      "name": name,
      "description": desc,
      "user": usr_id,
      "egg": parseInt(egg),
      "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
      "startup": startup_cmd,
      "environment": {
        "INST": "npm",
        "USER_UPLOAD": "0",
        "AUTO_UPDATE": "0",
        "CMD_RUN": "npm start"
      },
      "limits": {
        "memory": ram,
        "swap": 0,
        "disk": disknya,
        "io": 500,
        "cpu": cpu
      },
      "feature_limits": {
        "databases": 5,
        "backups": 5,
        "allocations": 5
      },
      deploy: {
        locations: [parseInt(loc)],
        dedicated_ip: false,
        port_range: [],
      },
    })
  });

  let result = await f2.json();
  if (result.errors) return conn.sendMessage(m.chat, JSON.stringify(result.errors[0], null, 2), { quoted: m });

  let server = result.attributes;
  var orang = isGroup ? m.sender : m.chat;
  var teks = `
*Berhasil Membuat Akun Panel ✅*

* *ID :* ${server.id}
* *Nama :* ${name}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
* *CPU :* ${cpu == "0" ? "Unlimited" : cpu + "%"}
* *Storage :* ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
* *Created :* ${desc}
`;

  let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
    "messageContextInfo": { "deviceListMetadata": {}, "deviceListMetadataVersion": 2 }, 
    interactiveMessage: proto.Message.InteractiveMessage.create({
      contextInfo: { mentionedJid: [m.sender], externalAdReply: { showAdAttribution: true }},
      body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
      footer: proto.Message.InteractiveMessage.Footer.create({ text: global.footer }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
        buttons: [{
          "name": "cta_url",
          "buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domain}\",\"merchant_url\":\"https://www.google.com\"}`
        }, {
          "name": "cta_copy",
          "buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
        }, {
          "name": "cta_copy",
          "buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
        }]
      })
    })} 
  }}, { userJid: m.sender, quoted: fverif });

  await conn.relayMessage(orang, msgii.message, { messageId: msgii.key.id });
  global.panel = null;
};

handler.command = [
  "cp1gb", "cp2gb", "cp3gb", // Tambahkan perintah lainnya sesuai dengan case yang ada
  "cp50gb", "cpunli"
];