const fetch = require('node-fetch');

// Community or group ID
const communityChatId = '120363301103806162@g.us';

let lastSentTime = 0; // Track the last time a birthday message was sent

let handler = async function(m, { conn }) {
    const sendBirthdayMessages = async () => {
        try {
            const response = await fetch('https://jkt-48-scrape-xi.vercel.app/api/birthdays');

            // Check if the response is successful
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();

            // Get the current date
            const today = new Date();
            const currentDate = today.getDate();
            const currentMonth = today.toLocaleString('id-ID', { month: 'long' });

            // Filter members whose birthday matches today's date and month
            const birthdayMembers = data.filter(member => {
                const [birthday, month] = member.birthday.split(' ');
                return parseInt(birthday) === currentDate && month.toLowerCase() === currentMonth.toLowerCase();
            });

            // Send a birthday message for each matching member
            for (const member of birthdayMembers) {
                const name = member.name || 'Unknown';
                const profileLink = `https://jkt48.com${member.profileLink}` || 'No profile link available';
                const imgSrc = member.imgSrc || 'No image available';

                let message = `🎉 *Selamat Ulang Tahun, ${name}!*\n\n`;
                message += `Semoga hari ulang tahunmu penuh dengan kebahagiaan dan keceriaan!\n`;
                message += `Lihat profil lengkapnya di sini: ${profileLink}\n`;

                // Send the birthday message to the community or group
                await conn.sendMessage(communityChatId, {
                    image: { url: imgSrc },
                    caption: message
                });

                // Update the last sent time
                lastSentTime = Date.now();
            }

        } catch (error) {
            // Handle errors by sending an error message to the user
            console.error(error);
            await conn.sendMessage(m.chat, { text: `Terjadi kesalahan saat mengambil data ulang tahun: ${error.message}` });
        }
    };

    // Send birthday messages if the date matches any member's birthday
    sendBirthdayMessages();

    // Command to manually check the list of upcoming birthdays
    const listBirthdays = async () => {
        try {
            const response = await fetch('https://jkt-48-scrape-xi.vercel.app/api/birthdays');

            // Check if the response is successful
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();

            let message = '🎂 *Daftar Ulang Tahun Member JKT48*\n\n';
            for (const member of data) {
                const name = member.name || 'Unknown';
                const birthday = member.birthday || 'Unknown';
                const profileLink = `https://jkt48.com${member.profileLink}` || 'No profile link available';

                message += ` *Nama*: ${name}\n`;
                message += ` *Tanggal Ulang Tahun*: ${birthday}\n`;
                message += ` *Profil*: ${profileLink}\n\n`;
            }

            // Send the list of upcoming birthdays to the user
            await conn.sendMessage(m.chat, { text: message });

        } catch (error) {
            // Handle errors by sending an error message to the user
            console.error(error);
            await conn.sendMessage(m.chat, { text: `Terjadi kesalahan saat mengambil daftar ulang tahun: ${error.message}` });
        }
    };

    // If the command is executed, show the list of upcoming birthdays
    if (m.text.toLowerCase().startsWith('jkt48birthdays')) {
        listBirthdays();
    }
};

// Set an interval to check and send birthday messages daily
setInterval(() => {
    const now = Date.now();
    const oneDayInMs = 24 * 60 * 60 * 1000;

    // Check if 24 hours have passed since the last message was sent
    if (now - lastSentTime >= oneDayInMs) {
        handler({ conn: null });
    }
}, 60 * 60 * 1000); // Check every hour

handler.help = ['jkt48birthdays'];
handler.tags = ['jkt48'];
handler.command = /^(jkt48birthdays)$/i;

module.exports = handler;