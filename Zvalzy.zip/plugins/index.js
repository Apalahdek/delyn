const fs = require('fs');
const path = require('path');

// Menggunakan __dirname untuk memastikan path yang benar
const pluginsDir = path.join(__dirname);
const plugins = {};

fs.readdirSync(pluginsDir).forEach(file => {
  if (file.endsWith('.js') && file !== 'index.js') {
    const pluginName = path.basename(file, '.js');
    plugins[pluginName] = require(path.join(pluginsDir, file));
  }
});

module.exports = plugins;