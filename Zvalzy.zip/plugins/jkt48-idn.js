const axios = require('axios');
const cheerio = require('cheerio');
const cron = require('node-cron');
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys");

let lastSentStreams = new Set(); // Set untuk menyimpan ID stream yang sudah dikirim

// Fungsi untuk memantau live stream
const checkLiveStreams = async (conn) => {
    try {
        // URL halaman live stream IDN App
        const url = 'https://www.idn.app/';
        
        // Ambil data dari halaman live stream
        const response = await axios.get(url);
        const $ = cheerio.load(response.data);

        // Cari elemen yang berisi live stream
        // Sesuaikan selector dengan struktur halaman IDN App
        const liveStreams = [];
        $('a[href^="/ale-1zwpdv/live/"]').each((index, element) => {
            const title = $(element).find('.title').text().trim();
            const link = `https://www.idn.app${$(element).attr('href')}`;
            const streamId = $(element).attr('href').split('/').pop(); // Ambil ID stream dari URL

            if (title.toLowerCase().includes('jkt48') && !lastSentStreams.has(streamId)) {
                liveStreams.push({
                    title,
                    link,
                    id: streamId
                });
                lastSentStreams.add(streamId); // Tambahkan ID stream ke set
            }
        });

        if (liveStreams.length === 0) {
            console.log('Tidak ada live stream dengan kata "JKT48" saat ini.');
            return;
        }

        // Buat pesan untuk WhatsApp
        let message = 'Berikut adalah live stream yang mengandung "JKT48":\n\n';
        liveStreams.forEach(stream => {
            message += `Judul: ${stream.title}\n`;
            message += `Link: ${stream.link}\n`;
            message += `\n`;
        });

        // Kirim pesan ke WhatsApp
        const communityId = "120363301103806162@g.us"; // Ganti dengan ID komunitas WhatsApp Anda

        // Mempersiapkan pesan
        const messageContent = {
            extendedTextMessage: {
                text: message
            }
        };

        // Membuat pesan dari konten
        let msg = generateWAMessageFromContent(communityId, messageContent, {});

        // Mengirim pesan ke komunitas WhatsApp
        await conn.relayMessage(communityId, msg.message, { messageId: msg.key.id });

        console.log('Sukses mengirim informasi live stream ke komunitas WhatsApp.');

    } catch (error) {
        console.error('Error:', error.message || error);
    }
};

// Fungsi untuk memulai pemantauan otomatis
const startMonitoring = (conn) => {
    // Jadwalkan pemantauan setiap 10 menit
    cron.schedule('*/10 * * * *', () => {
        console.log('Memeriksa live stream...');
        checkLiveStreams(conn);
    });
};

// Handler untuk perintah manual (opsional)
const handler = async (m, { conn }) => {
    if (m.command === 'livestreamjkt48') {
        await checkLiveStreams(conn);
        m.reply('Sukses memeriksa live stream untuk perintah manual.');
    }
};

handler.help = ['livestreamjkt48'];
handler.tags = ['live'];
handler.command = /^(livestreamjkt48)$/i;

module.exports = { handler, startMonitoring };