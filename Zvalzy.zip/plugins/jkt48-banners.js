const fetch = require('node-fetch');

let lastSentTime = 0; // Track the last time the message was sent

let handler = async function(m, { conn }) {
    const sendBanners = async (count) => {
        try {
            const response = await fetch('https://jkt-48-scrape-xi.vercel.app/api/banners');

            // Check if the response is successful
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();

            // Check if the data is valid or empty
            if (!data || !Array.isArray(data.data) || data.data.length === 0) {
                throw new Error('Invalid data format or no banners available');
            }

            // Determine how many banners to send (maximum of available banners)
            const bannersToSend = Math.min(count, data.data.length);

            // Loop through each selected banner and send a message for each
            for (let i = 0; i < bannersToSend; i++) {
                const banner = data.data[i];
                const imgUrl = banner.img_url || 'No image URL available';
                const value = banner.value || 'No value available';

                // Send the image as a separate message
                await conn.sendMessage(m.chat, {
                    image: { url: imgUrl },
                    caption: `More info: ${value}`
                });
            }

            // Update the last sent time
            lastSentTime = Date.now();

        } catch (error) {
            // Handle errors by sending an error message to the user
            console.error(error);
            await conn.sendMessage(m.chat, { text: `Terjadi kesalahan saat mengambil banner: ${error.message}` });
        }
    };

    // Get the count from the command
    const args = m.text.split(' ').slice(1); // Get the command arguments
    const count = args[0] ? parseInt(args[0], 10) : 1; // Default to 1 if no count is provided

    if (isNaN(count) || count <= 0) {
        return conn.sendMessage(m.chat, { text: 'Silakan masukkan angka yang valid untuk jumlah foto yang ingin dikirim.' });
    }

    // Inform the user how to use the command
    await conn.sendMessage(m.chat, { text: `Anda dapat mengatur jumlah foto yang ingin dikirim dengan menggunakan command: *jkt48banners <jumlah>*` });

    // Call the function to send the specified number of banners
    sendBanners(count);
};

handler.help = ['jkt48banners <count>'];
handler.tags = ['jkt48'];
handler.command = /^(jkt48banners)$/i;

module.exports = handler;