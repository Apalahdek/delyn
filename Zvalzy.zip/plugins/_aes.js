const crypto = require('crypto');

const algorithm = 'aes-128-cbc';
const key = crypto.randomBytes(16); // Kunci harus berukuran 16 bytes untuk AES-128
const iv = crypto.randomBytes(16);  // Initialisation Vector (IV) untuk AES

// Fungsi untuk mengenkripsi teks
function encrypt(text) {
  let cipher = crypto.createCipheriv(algorithm, Buffer.from(key), iv);
  let encrypted = cipher.update(text);
  encrypted = Buffer.concat([encrypted, cipher.final()]);
  return { iv: iv.toString('hex'), encryptedData: encrypted.toString('hex') };
}

// Fungsi untuk mendekripsi teks
function decrypt(text, iv) {
  let ivBuffer = Buffer.from(iv, 'hex');
  let encryptedText = Buffer.from(text, 'hex');
  let decipher = crypto.createDecipheriv(algorithm, Buffer.from(key), ivBuffer);
  let decrypted = decipher.update(encryptedText);
  decrypted = Buffer.concat([decrypted, decipher.final()]);
  return decrypted.toString();
}

// Enkripsi password
const password = 'jessica chandra';
const encryptedPassword = encrypt(password);
console.log(`Encrypted Password: ${encryptedPassword.encryptedData}`);
console.log(`IV: ${encryptedPassword.iv}`);