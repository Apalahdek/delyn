let { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys");

let handler = async (m, { conn, command }) => {
  let query = `${command} jkt48`;
  m.react('🕒');

  try {
    let anu = await pinterest(query);
    let kemii = await pickRandom(anu);
    let msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          "messageContextInfo": {
            "deviceListMetadata": {},
            "deviceListMetadataVersion": 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({
              text: kemii.grid_title
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: global.footer
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              hasMediaAttachment: true,
              ...(await prepareWAMessageMedia({ image: { url: kemii.images_url } }, { upload: conn.waUploadToServer }))
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  "name": "quick_reply",
                  "buttonParamsJson": `{"display_text":"Next Search","id": ".${command}"}`
                }
              ],
            })
          })
        }
      }
    }, { userJid: m.chat, quoted: m });
    await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
    await m.react('');
  } catch (e) {
    conn.reply(m.chat, `❌ Cooldown. Please wait a moment.`, m);
  }
};

handler.help = ['Alya', 'Anin', 'Anindya', 'Cathy', 'Elin', 'Eline', 'Chelsea', 'Cynthia', 'Danella', 'Daisy', 'Gendis', 'Michie', 'Aralie', 'Deline', 'Delynn', 'Delyn', 'Lana', 'Erin', 'Erine', 'Fritzy', 'Lily', 'Trisha', 'Kimi', 'Kimy', 'Nala', 'Ribka', 'Reggie', 'Regi', 'Oline', 'Nachia', 'Nayla', 'Levi', 'Kimmy', 'Moreen', 'Feni', 'Gracia', 'Gita', 'Christy', 'Zee', 'Olla', 'Freya', 'Eli', 'Jessi', 'Jeci', 'Muthe', 'Fiony', 'Cepio', 'Oniel', 'Flora', 'Lulu', 'Adel', 'Indah', 'Kathrina', 'Kathrin', 'Marsha', 'Amanda', 'Lia', 'Callie', 'Ella', 'Indira', 'Lyn', 'Raisha', 'Gracie', 'Greesel'];
handler.tags = ['jkt48'];
handler.command = /^(Alya|Anin|Anindya|Cathy|Elin|Eline|Chelsea|Cynthia|Danella|Daisy|Gendis|Michie|Aralie|Deline|Delynn|Delyn|Lana|Erin|Erine|Fritzy|Lily|Trisha|Kimi|Kimy|Nala|Ribka|Reggie|Regi|Oline|Nachia|Nayla|Levi|Kimmy|Moreen|Feni|Gracia|Gita|Christy|Zee|Olla|Freya|Eli|Jessi|Jeci|Muthe|Fiony|Cepio|Oniel|Flora|Lulu|Adel|Indah|Kathrina|Kathrin|Marsha|Amanda|Lia|Callie|Ella|Indira|Lyn|Raisha|Gracie|Greesel)$/i;

module.exports = handler;

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}

async function pinterest(query) {
  const baseUrl = 'https://www.pinterest.com/resource/BaseSearchResource/get/';
  const queryParams = {
    source_url: '/search/pins/?q=' + encodeURIComponent(query),
    data: JSON.stringify({
      options: {
        isPrefetch: false,
        query,
        scope: 'pins',
        no_fetch_context_on_resource: false
      },
      context: {}
    }),
    _: Date.now()
  };
  const url = new URL(baseUrl);
  Object.entries(queryParams).forEach(entry => url.searchParams.set(entry[0], entry[1]));

  try {
    const json = await (await fetch(url.toString())).json();
    const results = json.resource_response?.data?.results ?? [];
    return results.map(item => ({
      pin: 'https://www.pinterest.com/pin/' + item.id ?? '',
      link: item.link ?? '',
      created_at: (new Date(item.created_at)).toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      }) ?? '',
      id: item.id ?? '',
      images_url: item.images?.['736x']?.url ?? '',
      grid_title: item.grid_title ?? ''
    }));
  } catch (error) {
    console.error('Error fetching data:', error);
    return [];
  }
}