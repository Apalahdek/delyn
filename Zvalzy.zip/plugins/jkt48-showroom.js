const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys");

const handler = async (m, { conn, text }) => {
    if (!text) return m.reply("Text?");
    const getFormattedDateTimeWIB = () => {
    const now = new Date();
    
    // Convert to UTC
    const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
    
    // Convert to WIB (UTC+7)
    const wibTime = new Date(utc + (7 * 3600000));
    
    const day = String(wibTime.getDate()).padStart(2, '0');
    const month = String(wibTime.getMonth() + 1).padStart(2, '0');
    const year = String(wibTime.getFullYear()).substring(2);
    const hours = String(wibTime.getHours()).padStart(2, '0');
    const minutes = String(wibTime.getMinutes()).padStart(2, '0');
    const seconds = String(wibTime.getSeconds()).padStart(2, '0');
    
    return `${day}/${month}/${year} ${hours}.${minutes}.${seconds} WIB`;
};

    let pesan = m.text; // Capture the entire message text
    let urlMatch = pesan.match(/https?:\/\/[^\s]+/); // Extract the URL from the message
    let extractedUrl = urlMatch ? urlMatch[0] : "https://404-gamma-blue.vercel.app"; // Default URL if no URL is found
    let zyro = "https://telegra.ph/file/ea66a5944e1cf0be30bbc.jpg"; // Image URL for thumbnail
    let pp = await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://i.ibb.co/2WzLyGk/profile.jpg'); // Fallback for profile picture
    
    // Fake contact for quoting
    let fkon = { 
        key: { 
            fromMe: false, 
            participant: `0@s.whatsapp.net`, 
            ...(m.chat ? { remoteJid: `status@broadcast` } : {}) 
        }, 
        message: { 
            'contactMessage': { 
                'displayName': wm, 
                'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${wm},;;;\nFN:${wm},\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabell:Ponsel\nEND:VCARD`, 
                'jpegThumbnail': pp, 
                thumbnail: pp, 
                sendEphemeral: true 
            }
        }
    };

    // Target Group and Newsletter IDs
    const communityIds = ["120363166064514381@g.us", "120363325807220090@g.us",
"120363316296787422@g.us"];
    const newsletterIds = ["120363315095699482@newsletter"];

    // Prepare media (image) for contextInfo
    const contextImage = await prepareWAMessageMedia({ image: { url: zyro } }, { upload: conn.waUploadToServer });

    // Define the fake object
let fake = {
    contextInfo: {
        isForwarded: true,
        forwardingScore: 999,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363315095699482@newsletter',
            newsletterName: 'NOTIFICATION BY ©VALZYY',
            serverMessageId: -1
        },
        externalAdReply: {
            mediaUrl: 'https://telegra.ph/file/b9f6036aa4c5cef2e6221.jpg',
            mediaType: 1,
            title: 'JKT48 NOTIFICATIONS',
            body: getFormattedDateTimeWIB(), // Using WIB formatted date-time
            thumbnailUrl: 'https://telegra.ph/file/b9f6036aa4c5cef2e6221.jpg'
        }
    }
};

    // Function to send a message to a newsletter with image in contextInfo
    const sendMessageToNewsLetter = (jid, text, options = {}) => {
        const messages = { 
            extendedTextMessage: {
                text: text,
                ...options
            }
        };

        const messageToChannel = proto.Message.encode(messages).finish();
        const result = {
            tag: 'message',
            attrs: { to: jid, type: 'text' },
            content: [
                {
                    tag: 'plaintext',
                    attrs: {},
                    content: messageToChannel
                }
            ]
        };

        return conn.query(result);
    };

    // Send to WhatsApp Groups
    for (const communityId of communityIds) {
        let msg = generateWAMessageFromContent(communityId, {
            viewOnceMessage: {
                message: {
                    "messageContextInfo": {
                        "deviceListMetadata": {},
                        "deviceListMetadataVersion": 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: pesan // Sending the full message including the command
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: "© JKT48"
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: "",
                            subtitle: "BROADCAST",
                            hasMediaAttachment: true,
                            ...(await prepareWAMessageMedia({ document: { url: 'https://wa.me/' }, mimetype: 'image/png', fileName: `𝐽𝑘𝑡48 𝑁𝑜𝑡𝑖𝑓𝑖𝑐𝑎𝑡𝑖𝑜𝑛𝑠`, jpegThumbnail: await conn.resize(zyro, 400, 400), fileLength: 0 }, { upload: conn.waUploadToServer }))
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [{
                                "name": "cta_url",
                                "buttonParamsJson": JSON.stringify({
                                    display_text: "Lɪʜᴀᴛ ʟɪᴠᴇ 🎥",
                                    url: extractedUrl, // Using extracted URL
                                    merchant_url: extractedUrl // Using extracted URL
                                })
                            },
                            {
                                "name": "cta_copy",
                                "buttonParamsJson": `{\"display_text\":\"Cᴏᴘʏ ʟɪɴᴋ 📑\",\"id\":\"123456789\",\"copy_code\":\"${extractedUrl}\"}`
                            },
                            {
                                "name": "cta_url",
                                "buttonParamsJson": JSON.stringify({
                                    display_text: "Wᴇʙsɪᴛᴇ ʙᴏᴛ 🌐",
                                    url: "https://www.valzyofc.my.id", // Fixed URL
                                    merchant_url: "https://www.valzyofc.my.id" // Fixed URL
                                })
                            }]
                        })
                    })
                }
            }
        }, { quoted: fkon });

        await conn.relayMessage(msg.key.remoteJid, msg.message, {
            messageId: msg.key.id
        }).catch(_ => _);
    }

    // Send to WhatsApp Newsletters with image in contextInfo
    for (const newsletterId of newsletterIds) {
        sendMessageToNewsLetter(newsletterId, pesan, fake); // Pass the 'fake' object as the third argument
    }

    m.reply(`Sukses Mengirim Broadcast Ke Grup Komunitas dan Newsletter`);
};

handler.help = ['bcgcbutton <teks>'];
handler.tags = ['owner'];
handler.command = /^(si|Si|live|Live|Alya|Anin|Anindya|Cathy|Elin|Eline|Chelsea|Cynthia|Danella|Daisy|Gendis|Michie|Aralie|Deline|Delynn|Delyn|Lana|Erin|Erine|Fritzy|Lily|Trisha|Kimi|Kimy|Nala|Ribka|Reggie|Regi|Oline|Nachia|Nayla|Levi|Kimmy|Moreen|Feni|Gracia|Gita|Christy|Zee|Olla|Freya|Eli|Jessi|Jeci|Muthe|Fiony|Cepio|Oniel|Flora|Lulu|Adel|Indah|Kathrina|Kathrin|Marsha|Amanda|Lia|Callie|Ella|Indira|Lyn|Raisha|Gracie|GreeselREPLAY)$/i;
handler.admin = false;

module.exports = handler;