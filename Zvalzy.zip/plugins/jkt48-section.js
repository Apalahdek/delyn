const fetch = require('node-fetch');

let lastSentTime = 0; // Track the last time the message was sent

let handler = async function(m, { conn }) {
    const sendSchedule = async () => {
        try {
            const response = await fetch('https://jkt-48-scrape-xi.vercel.app/api/schedule/section');

            // Check if the response is successful
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();

            // Check if the data is valid or empty
            if (!data || !Array.isArray(data) || data.length === 0) {
                throw new Error('Invalid data format or no schedule available');
            }

            // Thumbnail and source URLs for contextInfo
            const thumbnailUrl = 'https://static.showroom-live.com/image/room/cover/73f495d564945090f4af7338a42ce09ffa12d35fbfa8ce35c856220bcf96c5f3_m.png?v=1715261567'; // Replace with a valid thumbnail URL
            const sourceUrl = 'https://nextzy.io'; // Replace with a relevant source URL

            // Build the theater schedule message with all sections
            let message = '📅 *JKT48 Section*\n\n';
            for (const section of data) {
                const tanggal = section.tanggal || 'Unknown';
                const hari = section.hari || 'Unknown';
                const bulan = section.bulan || 'Unknown';

                // Extract all event names from the events array
                const events = section.events || [];
                const eventNames = events.map(event => event.eventName).join(', ') || 'No event names available';

                message += ` *Tanggal*: ${tanggal}\n`;
                message += ` *Hari*: ${hari}\n`;
                message += ` *Bulan*: ${bulan}\n`;
                message += ` *Event Names*: ${eventNames}\n\n`;
            }

            // Send the complete message to the user who invoked the command
            await conn.sendMessage(m.chat, {
                text: message,
                contextInfo: {
                    externalAdReply: {
                        title: "JKT48 Section",
                        body: "",
                        mediaType: 1,
                        renderLargerThumbnail: false,  // Display the image in large size
                        thumbnailUrl: thumbnailUrl,
                        sourceUrl: sourceUrl,
                    }
                }
            });

            // Update the last sent time
            lastSentTime = Date.now();

        } catch (error) {
            // Handle errors by sending an error message to the user
            console.error(error);
            await conn.sendMessage(m.chat, { text: `Terjadi kesalahan saat mengambil jadwal teater: ${error.message}` });
        }
    };

    // Set an interval to send the schedule every 13 hours
    setInterval(() => {
        const now = Date.now();
        const thirteenHoursInMs = 13 * 60 * 60 * 1000;

        // Check if 13 hours have passed since the last message was sent
        if (now - lastSentTime >= thirteenHoursInMs) {
            sendSchedule();
        }
    }, 60 * 60 * 1000); // Check every hour

    // Call it once immediately to send the schedule without waiting for the first interval
    sendSchedule();
};

handler.help = ['jkt48section'];
handler.tags = ['jkt48'];
handler.command = /^(jkt48section)$/i;

module.exports = handler;