let levelling = require('../lib/levelling');
let fs = require('fs');
let path = require('path');
let fetch = require('node-fetch');
let axios = require('axios');
let os = require('os');
let { platform } = require('node:process');
let canvafy = require ('canvafy');
let { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys") 

const userStates = {}; // In-memory storage for user-specific indices and previous index

let sigma = 'https://telegra.ph/file/46fd8bf4e9d4840b274b5.jpg';
let valzy = {"key":{"remoteJid":"628551000185@s.whatsapp.net","fromMe":false,"id":"84F093999D8F9D371C74CA71ECED8D45"},"message":{"newsletterAdminInviteMessage":{"newsletterJid":"120363315095699482@newsletter","newsletterName":"NextzyDev","caption":"Powered By Valzyy","inviteExpiration":"1721259822"}}}
let handler = async function(m, { conn, args, usedPrefix, command }) {
    const userId = m.sender;
    const state = userStates[userId] || { currentIndex: 0, previousIndex: null };

    if (args[0] === 'next') {
        state.previousIndex = state.currentIndex; // Store the current index before moving to the next
        state.currentIndex++; // Move to the next member
    } else if (args[0] === 'return') {
        if (state.previousIndex === null) {
            await conn.sendMessage(m.chat, { text: 'No previous member data available.' });
            return;
        }
        state.currentIndex = state.previousIndex; // Revert to the previous index
        state.previousIndex = null; // Clear the previous index after returning
    } else if (args.length === 0) {
        // If no arguments, show the first member
        state.previousIndex = null; // No previous data when starting fresh
        state.currentIndex = 0;
    } else {
        // Handle invalid commands
        await conn.sendMessage(m.chat, { text: 'Invalid command. Use `jkt48member` to see the first member, `jkt48member next` to see the next member, or `jkt48member return` to go back to the previous member.' });
        return;
    }

    userStates[userId] = state; // Update the user's state

    const sendMemberData = async (index) => {
        try {
            const response = await fetch('https://sorum-valz-store.vercel.app/api/rooms');

            // Check if the response is successful
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();

            // Check if the data is valid or empty
            if (!data || !Array.isArray(data) || data.length === 0) {
                throw new Error('Invalid data format or no members found');
            }

            // Check if the index is within bounds
            if (index < 0 || index >= data.length) {
                await conn.sendMessage(m.chat, { text: 'No more members available.' });
                return;
            }

            // Get the specific member data based on index
            const member = data[index];

            // Construct the message content
            let messageContent = '👤 *JKT48 Member Info*\n\n';
            messageContent += `*Name*: ${member.name}\n`;
           messageContent += `*URL*: https://www.showroom-live.com/${member.url_key}\n`;
           messageContent += `*Room ID*: ${member.id}\n`;
            messageContent += `*Follower Count*: ${member.follower_num}\n`;
            messageContent += `*Description*: ${member.description}\n\n`;
            
            // Use the image from the member data
            const thumbnailUrl = member.image_url || 'https://telegra.ph/file/c6ec9739b1a4ee238b325.jpg';

            // Send the message with dynamic content for the specified member
  let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
        contextInfo: {
        	mentionedJid: [m.sender], 
        	isForwarded: true, 
	        forwardedNewsletterMessageInfo: {
			newsletterJid: '120363288101737637@newsletter',
			newsletterName: '© Valzyofc', 
			serverMessageId: -1
	    	},
            externalAdReply: {
            title: member.name, 
            body: 'Feature Version: 1.0.5',
            thumbnailUrl: thumbnailUrl,
            sourceUrl: '',
            mediaType: 1,
            renderLargerThumbnail: true
            },
          }, 
body: proto.Message.InteractiveMessage.Body.create({
  text: messageContent
  }),
  footer: proto.Message.InteractiveMessage.Footer.create({
  text: '© 2011 - 2024 | JKT48'
  }),
  header: proto.Message.InteractiveMessage.Header.create({
  hasMediaAttachment: true,...(await prepareWAMessageMedia({ document: { url: 'https://wa.me/' }, mimetype: 'image/png', fileName: `${name}`, jpegThumbnail: await conn.resize(sigma, 400, 400), fileLength: 0 }, { upload: conn.waUploadToServer }))
  }),
  nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
  buttons: [
  {
  "name": "quick_reply",
  "buttonParamsJson": `{"display_text":"Next Search","id": ".${command} next"}`
  },
  {
  "name": "quick_reply",
  "buttonParamsJson": `{"display_text":"Previous Search","id": ".${command} return"}`
  }
  ],
  })
  })
  }
  }
  }, { userJid: m.chat, quoted: valzy })
  await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
        } catch (error) {
            // Handle errors by sending an error message to the user
            console.error(error);
            await conn.sendMessage(m.chat, { text: `Terjadi kesalahan saat mengambil data member: ${error.message}` });
        }
    };

    // Call the function to send member data
    sendMemberData(state.currentIndex);
};

handler.help = ['memberinfo [next|return]'];
handler.tags = ['jkt48'];
handler.command = /^(memberinfo|jkt48member)$/i;

module.exports = handler;
