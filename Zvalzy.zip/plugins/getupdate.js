const fs = require('fs');
const path = require('path');

let handler = async (m, { conn, args }) => {
    // Nama kategori yang diberikan oleh pengguna
    const category = args[0] ? args[0].toLowerCase() : ''; // Mengambil argumen pertama sebagai kategori, jika ada

    // Path dasar untuk folder "valzyy"
    const baseFolderPath = './valzyy'; // Sesuaikan dengan direktori utama Anda

    // Path folder untuk kategori tertentu di dalam folder "valzyy"
    const categoryFolderPath = path.join(baseFolderPath, category);

    // Menampilkan reaksi saat memproses
    conn.sendMessage(m.chat, {
        react: {
            text: '🕒',
            key: m.key,
        }
    });

    try {
        // Memeriksa apakah folder kategori ada
        if (!fs.existsSync(categoryFolderPath)) {
            return conn.reply(m.chat, `🚫 Kategori "${category}" tidak ditemukan di dalam folder "valzyy". Pastikan nama kategori benar.`, m);
        }

        // Membaca file dari folder kategori
        const files = fs.readdirSync(categoryFolderPath);

        // Memeriksa apakah folder kosong
        if (files.length === 0) {
            return conn.reply(m.chat, `🚫 Tidak ada file yang tersedia dalam kategori "${category}" di folder "valzyy".`, m);
        }

        // Mengambil file pertama yang ditemukan di folder kategori
        const fileToSend = path.join(categoryFolderPath, files[0]);

        // Mengirimkan file ke pengguna
        await conn.sendMessage(m.chat, {
            document: { url: fileToSend },
            mimetype: 'application/octet-stream', // Atur MIME type sesuai dengan jenis file Anda
            fileName: path.basename(fileToSend),
        }, { quoted: m });

    } catch (error) {
        console.log(error);
        conn.reply(m.chat, '🐱 Maaf, saya tidak dapat memproses permintaan Anda.', m);
    }
};

// Menyesuaikan bantuan dan tag command
handler.help = ['getupdate <kategori>'];
handler.tags = ['downloader'];
handler.command = /^(getupdate)$/i;

module.exports = handler;