// listMainMenusHandler.js
const { Button } = require('your-button-library'); // Ganti dengan library button yang sesuai
const menuPlugin = require('./menuPlugin');

let handler = async (m, { conn }) => {
  // Filter menu dengan tag 'main'
  const mainMenus = menuPlugin.menus.filter(menu => menu.tag === 'main');

  // Buat pesan dengan daftar menu
  const menuList = mainMenus.map(menu => `- ${menu.name}`).join('\n');

  // Buat pesan dengan Button
  return new Button()
    .setBody(`*List Menu - Main Tag*\n\n${menuList}`)
    .setFooter('Footer text here') // Ganti dengan footer yang sesuai
    .setImage('https://example.com/image.jpg') // Ganti dengan URL gambar yang sesuai
    .addUrl('Customer Support', 'https://wa.me/628816609112')
    .run(m.chat, conn, m);
};

handler.help = ['listmenu'];
handler.tags = ['info', 'main'];
handler.command = /^(7781)$/i;
handler.register = false;

module.exports = handler;