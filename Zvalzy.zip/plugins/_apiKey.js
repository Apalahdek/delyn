let handler = m => m
handler.all = async function (m) {
global.alyapi = 'Kemii-san' // Alya Apikey
global.roseapi = '1HO9r7vrIfscoM6n0Kgpd0k9A3U7twXdnvJ80wB1jj5zy5E2dd4HsjP1tyqZ6TaC' // Rose Apikey
global.lolkey = 'pentilkuda' // Lolhuman Apikey
global.neoapi = 'swetyy' // Neoxr Apikey
}

module.exports = handler