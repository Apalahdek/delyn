let handler = async (m, { conn, args }) => {
    if (!args[0]) {
        await conn.sendMessage(m.chat, { text: 'Please provide your name, e.g., *cekoshi valzy*' });
        return;
    }

    const userName = args[0];

    const sendMemberData = async () => {
        try {
            const response = await fetch('https://sorum-valz-store.vercel.app/api/rooms');

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();

            if (!data || !Array.isArray(data) || data.length === 0) {
                throw new Error('Invalid data format or no members found');
            }

            const randomIndex = Math.floor(Math.random() * data.length);
            const member = data[randomIndex];

            let messageContent = `👤 *Oshi ${userName}*\n\n`;
            messageContent += `${member.description}\n\n`;

            const thumbnailUrl = member.image_url || 'https://telegra.ph/file/c6ec9739b1a4ee238b325.jpg';

            return new Button()
                .setBody(messageContent)
                .setFooter('© 2011 - 2024 | JKT48')
                .setImage(thumbnailUrl)
                .run(m.chat, conn, m);

        } catch (error) {
            console.error(error);
            await conn.sendMessage(m.chat, { text: `Terjadi kesalahan saat mengambil data member: ${error.message}` });
        }
    };

    sendMemberData();
};

handler.help = ['cekoshi [name]'];
handler.tags = ['jkt48'];
handler.command = /^cekoshi$/i;

module.exports = handler;