const fetch = require('node-fetch');

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
  // Mengecek apakah pengguna memasukkan nama
  if (!args[0]) return conn.reply(m.chat, `Harap masukkan nama setelah perintah!\n\nContoh: *${usedPrefix}${command} valzy*`, m);
  
  let nama = args[0]; // Mengambil nama dari argumen

  // Mengirimkan pesan ke nomor yang ditentukan
  let nomorTujuan = '6285701479245@s.whatsapp.net'; // Nomor tujuan

  let pesan = `.cp1gb ${nama}`; // Pesan yang akan dikirimkan

  // Mengirim pesan
  try {
    await conn.sendMessage(nomorTujuan, { text: pesan }, { quoted: m });
    conn.reply(m.chat, `Pesan telah dikirim ke nomor ${nomorTujuan}:\n${pesan}`, m);
  } catch (err) {
    console.error(err);
    conn.reply(m.chat, `Terjadi kesalahan saat mengirim pesan: ${err.message}`, m);
  }
};

handler.help = ['buypanel <nama>']; // Bantuan untuk perintah
handler.tags = ['panel']; // Tag untuk mengelompokkan handler
handler.command = /^buypanel$/i; // RegEx untuk memicu handler dengan perintah 'buypanel'
handler.owner = true; // Hanya bisa digunakan oleh owner

module.exports = handler;