const fetch = require('node-fetch');

let handler = async function(m, { conn, args }) {
    try {
        const page = args[0] ? parseInt(args[0]) : 1;
        const maxPages = 189; // Maximum number of pages
        if (page < 1 || page > maxPages) {
            await conn.sendMessage(m.chat, { text: `Halaman tidak valid. Silakan pilih antara 1 dan ${maxPages}.` });
            return;
        }

        const response = await fetch(`https://jkt-48-scrape-xi.vercel.app/api/news/${page}`);

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const jsonResponse = await response.json();
        const newsData = jsonResponse.data;

        if (!newsData || !Array.isArray(newsData) || newsData.length === 0) {
            await conn.sendMessage(m.chat, { text: 'Tidak ada berita yang ditemukan pada halaman ini.' });
            return;
        }

        // Construct the message content
        let messageContent = `📰 *JKT48 News - Halaman ${page}*\n\n`;
        newsData.forEach((news, index) => {
            const title = news.title || 'No title available';
            const link = `https://jkt48.com${news.link || ''}`;
            const time = news.time || 'No time available';

            messageContent += `*${index + 1}. Title*: ${title}\n`;
            messageContent += `*Link*: ${link}\n`;
            messageContent += `*Time*: ${time}\n\n`;
        });

        // Add information about page selection
        messageContent += `\n🔄 Anda dapat memilih halaman dengan mengetik command diikuti nomor halaman yang ingin dilihat (misal: *jkt48news 2*).`;

        // Send the message content
        await conn.sendMessage(m.chat, { text: messageContent });

    } catch (error) {
        console.error(error);
        await conn.sendMessage(m.chat, { text: `Terjadi kesalahan saat mengambil berita: ${error.message}` });
    }
};

handler.help = ['jkt48news'];
handler.tags = ['jkt48'];
handler.command = /^(jkt48news)$/i;

module.exports = handler;