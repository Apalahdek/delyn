const axios = require('axios');
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys");

const communityId = "120363301103806162@g.us"; // ID komunitas WhatsApp
let activeLiveIds = new Set(); // Set untuk melacak siaran langsung yang aktif
let endedLiveIds = new Set(); // Set untuk melacak siaran langsung yang sudah berakhir

const checkShowroomLive = async (conn) => {
    try {
        // Ambil data dari API Showroom
        const response = await axios.get('https://www.showroom-live.com/api/live/onlives');
        
        // Buat Set untuk menyimpan link unik dan menghindari duplikasi
        const seen = new Set();

        // Filter data yang berisikan kalimat "JKT48"
        const jkt48Lives = response.data.onlives
            .map(group => group.lives) // Dapatkan array lives dari setiap grup
            .flat() // Gabungkan semua lives menjadi satu array
            .filter(live => live.main_name.includes('JKT48')) // Filter lives yang berisikan 'JKT48' pada main_name
            .filter(live => {
                const isDuplicate = seen.has(live.room_url_key); // Cek apakah link sudah ada
                seen.add(live.room_url_key); // Tambahkan link ke dalam Set
                return !isDuplicate; // Hanya kembalikan yang tidak duplikat
            });

        // Live yang baru ditemukan
        const newLives = jkt48Lives.filter(live => !activeLiveIds.has(live.room_url_key));
        // Live yang telah berakhir
        const endedLives = [...activeLiveIds].filter(liveId => !jkt48Lives.some(live => live.room_url_key === liveId));

        // Update set activeLiveIds dan endedLiveIds
        activeLiveIds = new Set(jkt48Lives.map(live => live.room_url_key));
        endedLiveIds = new Set(endedLives);

        // Jika ada live baru yang terdeteksi, kirim pesan
        if (newLives.length > 0) {
            let message = 'Berikut adalah siaran langsung JKT48 yang baru dimulai:\n\n';
            newLives.forEach(live => {
                message += `Nama: ${live.main_name}\n`;
                message += `Link: https://www.showroom-live.com/${live.room_url_key}\n`;
                message += `Mulai: ${new Date(live.started_at * 1000).toLocaleString('id-ID')}\n`;
                message += `\n`;
            });

            // Mempersiapkan pesan
            const messageContent = {
                extendedTextMessage: {
                    text: message
                }
            };

            let msg = generateWAMessageFromContent(communityId, messageContent, {});
            await conn.relayMessage(communityId, msg.message, { messageId: msg.key.id });

            console.log('Sukses mengirim informasi siaran langsung JKT48 yang baru dimulai ke komunitas.');
        }

        // Jika ada live yang baru saja berakhir, kirim pesan
        if (endedLives.length > 0) {
            let message = 'Siaran langsung JKT48 berikut telah berakhir:\n\n';
            endedLives.forEach(liveId => {
                message += `Link: https://www.showroom-live.com/${liveId}\n`;
                message += `\n`;
            });

            // Mempersiapkan pesan
            const messageContent = {
                extendedTextMessage: {
                    text: message
                }
            };

            let msg = generateWAMessageFromContent(communityId, messageContent, {});
            await conn.relayMessage(communityId, msg.message, { messageId: msg.key.id });

            console.log('Sukses mengirim informasi siaran langsung JKT48 yang berakhir ke komunitas.');
        }

    } catch (error) {
        console.error(error);
    }
};

// Command handler sebagai opsi manual
const handler = async (m, { conn }) => {
    await checkShowroomLive(conn);
};

handler.help = ['showroomjkt48'];
handler.tags = ['showroom'];
handler.command = /^(showroomjkt48)$/i;

module.exports = handler;

// Fungsi yang berjalan secara otomatis setiap interval tertentu
setInterval(async () => {
    const conn = {}; // Ganti dengan objek koneksi WhatsApp Anda
    await checkShowroomLive(conn);
}, 60000); // Interval cek setiap 60 detik