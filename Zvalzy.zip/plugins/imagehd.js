/*
  *  sᴄʀɪᴘᴛ ʙʏ ғᴏʀx ғʏʏʀᴇ
  *  Forbidden to share and delete my wm
  *  Tiktok : ʟᴠᴇғᴏʀᴄᴇ48
  *  ɢʀᴏᴜᴘ ᴡᴀ : https://chat.whatsapp.com/L61B3NooExIIfZpJ8ZHE7o
  *  ᴛᴇʟᴇɢʀᴀᴍ : t.me/FyyreForx
  *  Breach : ғᴏʀx ғʏʏʀᴇ
  *  ᴡʜᴀᴛsᴀᴀᴘ : wa.me/6281374382816
*/

let uploadImage = require ('../lib/pelerhd.js')
let fetch = require ('node-fetch')

let handler = async (m, { conn, usedPrefix, command }) => {
    try {
        let q = m.quoted ? m.quoted : m
        let mime = (q.msg || q).mimetype || ''
        if (!mime) return conn.reply(m.chat, `Send/Reply Images with the caption *.${command}*`, m)
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key }})
        let media = await q.download()
        let url = await uploadImage(media)
        let rara = await fetch(`https://widipe.com/remini?url=${url}&resolusi=4`)
        let mitsu = await rara.json()
        await conn.sendFile(m.chat, mitsu.url, '', '```Status Request :``` `Succes`', m)
    } catch (e) {
        conn.reply(m.chat, 'Waduh fitur HD nya lagi error, coba lagi nanti yah (⁠◍⁠•⁠ᴗ⁠•⁠◍⁠)', m)
        console.error(e)
    }
};

handler.help = ["enhancer", "hdr", "colorize","hd","unblur","remini","enhance"].map(v => v + ' *<image>*')
handler.tags = ["tools","hd"];
handler.premium = false;
handler.register = true
handler.limit = true
handler.command = ["unblur", "enhancer", "enhance", "hdr", "colorize","remini","hd"];
module.exports = handler